package sqlLoader;

import java.io.*;
import java.util.ArrayList;

public class Extractor {

	private int index = 0;
	public static String[] table_name = {"Student", "INSTRUCTOR", "COURSE", "COURSE_OFFERING", "GRADE"};
	private ArrayList<DataTable> DataTables;

	
	public Extractor() {

        String fileName = "school_data.txt";
        DataTables = new ArrayList<DataTable>();
        
        String line = null;

        try {
            FileReader fileReader = 
                new FileReader(fileName);

            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            DataTable table = null;
            
            while((line = bufferedReader.readLine()) != null) {
               
            	if(line.contains("% ")) {
            		table = new DataTable(table_name[index]);
            		
            		if(sqlLoader.debug) System.out.println("CREATING TABLE: " + table_name[index]);
            		
            		DataTables.add(table);	
            		
            		index++;
            	} else {
            		if(table != null && line.length() > 2) {
            			if(sqlLoader.debug) System.out.println(line);
            			table.insert(line);	
            		} 	
            	}
            }   
            bufferedReader.close(); 
            
            
            
            if(sqlLoader.debug) System.out.println("EXTRACTION COMPLETE");
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" + fileName + "'");                  
        }
    }
	
	
	public ArrayList<DataTable> getData(){
		return DataTables;
	}
	
}
