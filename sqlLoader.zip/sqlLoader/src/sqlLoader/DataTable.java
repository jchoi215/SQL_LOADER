package sqlLoader;

import java.util.ArrayList;

public class DataTable {
	
	public String table_name = "default";
	private ArrayList<String> list;
	
	public DataTable(String name) {
		table_name = name;
		list = new ArrayList<String>();
	}

	public void insert(String line) {
		list.add(line);
	}
	
	public ArrayList<String> getList() {
		return list;
	}
	
	public String getName() {
		return table_name;
	}
}


//String phrase = "the music made   it   hard      to        concentrate";
//String delims = "[ ]+";
//String[] tokens = phrase.split(delims);
//Note that
//
//the general form for specifying the delimiters that we will use is "[delim_characters]+" . (This form is a kind of regular expression. You don't need to know about regular expressions - just use the template shown here.) The plus sign (+) is used to indicate that consecutive delimiters should be treated as one.
//the split method returns an array containing the tokens (as strings).  To see what the tokens are, just use a for loop:
//for (int i = 0; i < tokens.length; i++)
//    System.out.println(tokens[i]);