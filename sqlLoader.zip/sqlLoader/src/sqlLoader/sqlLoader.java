package sqlLoader;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class sqlLoader {
	
	private static ArrayList<DataTable> data;
	private static Connection connection;
	
	public static boolean debug = false;
	
	private static String[] queries = {
			" insert into student (first_name, last_name, major) values (?, ?, ?)",
			" insert into instructor (first_name, last_name, department, salary) values (?, ?, ?, ?)",
			" insert into course (course_name, description) values (?, ?)",
			" insert into course_offering (course_id, instructor_id, semester) values (?, ?, ?)",
			" insert into grade (student_id, course_offering_id, grade) values (?, ?, ?)",
	};
	
	public static int[] goalLength = { 3, 4, 2, 3, 3};
	

	// ============================================================
	// RESET TABLE, GATHER DATA, GET CONNECTION, UPLOAD DATA
	// LASTLY STOP CONNECTION
	// ============================================================
		
	
	public static void main(String[] args)
	{
		RESET_TABLE();	
		Extractor DataExtractor = new Extractor();
		data = DataExtractor.getData();
		connection = getConnection();
		
		if(connection != null) insert();
		
		STOP_CONNECTION();
	}
	
	
	
	// ============================================================
	// OPEN CONNECTION, CLEAN OUT TABLE, RESET AUTO_INCREMENTATION
	// ============================================================
	
	public static void RESET_TABLE() {
		
		System.out.print("CLEANING IN PROGRESS...");
		
		Connection line = getConnection();
		
		String[] cleanCode = {
				"TRUNCATE TABLE SCDB.COURSE", 
				"TRUNCATE TABLE SCDB.COURSE_OFFERING",
				"TRUNCATE TABLE SCDB.GRADE",
				"TRUNCATE TABLE SCDB.INSTRUCTOR",
				"TRUNCATE TABLE SCDB.STUDENT",
		};
		
		try {
			for(int i = 0; i < cleanCode.length; i++) {
				PreparedStatement preparedStmt = line.prepareStatement(cleanCode[i]);	
				preparedStmt.execute();
			}
		} catch (Exception e) {
			System.out.println("[INCOMPLETE]");
		}
		
		
		System.out.println("[DONE]");
	}
	
	
	private static void STOP_CONNECTION() {
		
		System.out.print("Connection closing in progress...");
		
		try {
			if(connection != null) {
				connection.close();
				System.out.println("[done]");
			} 
			
		}catch(Exception e) {
			System.out.println("[INCOMPLETE]");
		}
	}
	
	
	// ============================================================
	// OPEN TEXT FILE W/ DATA, STORE AND PARSE
	// ============================================================
	
	public static void insert() {
		
		int index = 0;
		for(DataTable i: data) {
			
			ArrayList<String> list = (ArrayList<String>)i.getList();
			System.out.println("Data Table name: " + i.getName());
			
			
			for(int j = 0; j < list.size(); j++) 			
				insertHelper(index, list.get(j).split(","));
							
			index++;
		}
	}
	

	// ============================================================
	// PARSE DATA, OPEN CONNECTION, UPDATE SQL DATA BASE
	// ============================================================
	
	public static void insertHelper(int i, String[] args) {
		
		int shift = 0, argLength = args.length;
		
		if(goalLength[i] != argLength) shift = 1;
		
		
		if(debug) {
			for(int j = 0 + shift; j < argLength; j++) 
				System.out.println("" + j + ": "+ args[j]);
		}
		
		switch(i) {
//		" insert into student (first_name, last_name, major) values (?, ?, ?)",
			case 0: 		
				try {
					PreparedStatement preparedStmt = connection.prepareStatement(queries[i]);	
					preparedStmt.setString(1, args[0 + shift].toString());
					preparedStmt.setString(2, args[1 + shift]);
					preparedStmt.setString(3, args[2 + shift]);
					preparedStmt.execute();
				} catch(Exception e) {
					error(i);
				}break;
			
			case 1: 
//				" insert into instructor (first_name, last_name, department,salary) values (?, ?, ?, ?)",
				try {
					PreparedStatement preparedStmt = connection.prepareStatement(queries[i]);	
					preparedStmt.setString(1, args[0 + shift]);
					preparedStmt.setString(2, args[1 + shift]);
					preparedStmt.setString(3, args[2 + shift]);
					preparedStmt.setInt(4, Integer.parseInt(args[3 + shift]));
					preparedStmt.execute();
				} catch(Exception e) {
					error(i);
				}break;
		
			case 2: 
//				" insert into course (course_name, description) values (?, ?)",
				try {
					PreparedStatement preparedStmt = connection.prepareStatement(queries[i]);	
					preparedStmt.setString(1, args[0 + shift]);
					preparedStmt.setInt(2, Integer.parseInt(args[1 + shift]));
					preparedStmt.execute();
				} catch(Exception e) {
					error(i);
				}
				break;
			
			case 3: 
//				" insert into course_offering (course_id, instructor_id, semester) values (?, ?, ?)",
				try {
					PreparedStatement preparedStmt = connection.prepareStatement(queries[i]);	
					preparedStmt.setInt(1, Integer.parseInt(args[0 + shift]));
					preparedStmt.setInt(2, Integer.parseInt(args[1 + shift]));
					preparedStmt.setString(3, args[2 + shift]);
					preparedStmt.execute();
				} catch(Exception e) {
					error(i);
				}break;
			
			
			case 4: 
//				" insert into grade (student_id, course_offering_id, grade) values (?, ?, ?)",
				try {
					PreparedStatement preparedStmt = connection.prepareStatement(queries[i]);	
					preparedStmt.setInt(1, Integer.parseInt(args[0 + shift]));
					preparedStmt.setInt(2, Integer.parseInt(args[1 + shift]));
					preparedStmt.setInt(3, Integer.parseInt(args[2 + shift]));
					preparedStmt.execute();
				} catch(Exception e) {
					error(i);
				}break;
		
			default: return;
		}
	}
	

	// ============================================================
	// ESTABLISH CONNECTION TO SQL, RETURN CONNECTION LINK
	// ============================================================
	
	
	public static Connection getConnection() {
		try{
			  String myDriver = "org.gjt.mm.mysql.Driver";
			  String myUrl = "jdbc:mysql://localhost/scdb?autoReconnect=true&useSSL=false";
			  Class.forName(myDriver);
			  Connection conn = DriverManager.getConnection(myUrl, "root", "a11b49def4");
			  System.out.println("Connection SUCCESS");
			  return conn;
			}
			catch (Exception e){
				System.out.println("Connection FAILED");
				return null;
			}
	}
		
	public static void error(int i) {
		System.out.println("Error writing: " + queries[i]);
	}

} // =========================================================================================================================






//	private static void QueryInsert() {
//		
//		try{
//		  String myDriver = "org.gjt.mm.mysql.Driver";
//		  String myUrl = "jdbc:mysql://localhost/scdb";
//		  Class.forName(myDriver);
//		  Connection conn = DriverManager.getConnection(myUrl, "root", "A11b49def4");
//		  
//		  
//		  String query = " insert into student (first_name, last_name, major)"
//		+ " values (?, ?, ?)";
//			  
//		  PreparedStatement preparedStmt = conn.prepareStatement(query);
//		  
//		  preparedStmt.execute();	      
//		  conn.close();
//	  
//		}
//		catch (Exception e){
//		  System.err.println("Got an exception!");
//		      System.err.println(e.getMessage());
//		}
//	}
	
	
	
	
	
//	// FOR NOW THIS IS MUTED
//	private static void PrintDataTable() {
//		for(DataTable i: data) {
//			ArrayList<String> list = (ArrayList<String>)i.getList();
//			
//			for(int j = 0; j < list.size(); j++) {
//				System.out.println("Echo > " + list.get(j));
//			}
//		}
//	}	



//String query = " insert into student (first_name, last_name, major)"
//  + " values ('"+Jae+"', ?, ?)";


//preparedStmt.setString (1, "Barney");
//preparedStmt.setString (2, "Lva");
//preparedStmt.setString (3, "CS");//	     


//statement.executeUpdate("INSERT INTO Customers " + "VALUES (1002, 'McBeal', 'Ms.', 'Boston', 2004)");
//statement.executeUpdate("INSERT INTO Customers " + "VALUES (1003, 'Flinstone', 'Mr.', 'Bedrock', 2003)");
//statement.executeUpdate("INSERT INTO Customers " + "VALUES (1004, 'Cramden', 'Mr.', 'New York', 2001)");






////   SELECT FIRST_NAME
////FROM `scdb`.`student`;


//public class Main {
//	
////	private Boolean connection_successful = false;
////	
////	static Connection link;
////	
////	public static void main(String[] args) throws Exception {
////		
////		link = getConnection();
////		post();
////		
////	}
////	
////	public static void post() throws Exception {
////		
////		String status = "";
////		
//////		final String first = "John";
//////		final String last = "Doe";
//////		final String major = "CS";
////		
////		try {
////			
////			if(link != null) System.out.println("LINK ESTABLISHED");
////			else System.out.println("LINK WAS BROKEN");
////			
////			link = getConnection();
////			PreparedStatement posted = link.prepareStatement("INSERT INTO STUDENT (FIRST_NAME, LAST_NAME, MAJOR) VALUES (?,?,?)");
////			System.out.println("DID IT GET HERE2?");
////			
//////			String query = " insert into users (first_name, last_name, date_created, is_admin, num_points)"
//////			        + " values (?, ?, ?, ?, ?)";
////
////			
////			
////			posted.setString(1, "John");
////			posted.setString(2, "Doe");
////			posted.setString(3, "CS");
////			
////			System.out.println("DID IT GET HERE?");
////			posted.execute();
////			posted.close();
////			
////			status = "SUCCESS";
////		}catch(Exception e) {
////			status = "FAILED";
////		}finally {
////			System.out.println("INSERT " + status);
////		}
////	}
////	
////	
////	
////	
////	
////	public static Connection getConnection() throws Exception{
////		try {
////			Class.forName("com.mysql.jdbc.Driver");
////			return DriverManager.getConnection("jdbc:mysql://localhost:3306/schooldatabase?autoReconnect=true&useSSL=false","root", "A11b49def4");
////			
////		} catch (Exception e) {
////			System.out.println(e);
////		}
////		return null;
////	}
////	
////	
////	
//
////	  public static void main(String[] args)
////	  {
////	    try
////	    {
////	      String myDriver = "org.gjt.mm.mysql.Driver";
////	      String myUrl = "jdbc:mysql://localhost/scdb";
////	      Class.forName(myDriver);
////	      Connection conn = DriverManager.getConnection(myUrl, "root", "A11b49def4");
////
////	      
////	      String query = " insert into student (first_name, last_name, major)"
////	        + " values (?, ?, ?)";
////
////	      
////	      PreparedStatement preparedStmt = conn.prepareStatement(query);
////	      preparedStmt.setString (1, "Barney");
////	      preparedStmt.setString (2, "Lva");
////	      preparedStmt.setString (3, "CS");//	     
////	      
////	      preparedStmt.execute();	      
////	      conn.close();
////	      
////	    }
////	    catch (Exception e)
////	    {
////	      System.err.println("Got an exception!");
////	      System.err.println(e.getMessage());
////	    }
////	  }
//	
//
////      preparedStmt.setBoolean(4, false);
////      preparedStmt.setInt    (5, 5000);
//
//	
//}